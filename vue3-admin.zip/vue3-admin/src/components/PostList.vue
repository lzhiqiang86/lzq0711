<script setup>
import {ref,onMounted,reactive, watchEffect} from "vue";
import axios from "axios";
import router from "../router";
import { useRoute, useRouter } from "vue-router";

    const posts = ref([]);
    const con_ser = ref('');
    const pag = ref('1');
    const cs = ref([]);
    const load = async()=>{
    try {
        //具体传参数据，需要连接后台后，跟后端工程师配合调试
    let {data} = await axios("http://localhost:3308/posts",{params:{page:pag,keywords:"嘿嘿嘿"}})
    // console.log(data)
    posts.value = data[0].data;
    console.log(pag.value)
    cs.value = data[0]
    } catch (error) {
      console.log(error)
    }
  }
//   load();

watchEffect(()=>{
    console.log(load(),pag.value)
});

//一共多少条
 const total = ref(10);

 //一共分多少页显示
 const pageSize = ref(1);
 

 //当前页码
 const currentPage = ref(1);

 //变换页面后的当前页面
 function changePage(tt){
    currentPage.value = tt;
    pag.value  = tt;
    
  
 }

const routerr = useRouter();
function tiaozhuan(res){
    // router.push({name:'dashboard',params:{res:res}})
   console.log(res)

//    routerr.push({path:'dashboard',props:"http://www.baidu.com"})
//    console.log(res)
}



</script>
<template>
    <el-input v-model="con_ser" placeholder="搜索一下，你就知道" clearable class="inpt"></el-input>
    <el-button type="primary">搜索</el-button>
    <div> 
        <div class="post-list">
            <div v-for="post in posts" :key="post.id" class="ser_result">
                <router-link :to="{name:'dashboard',query:{tp:post.addr}}">
                    <div >
                    <h1 class="bt">
                    {{post.title}}
                    </h1>
                    </div>
                    <div>
                        <p>
                            {{post.addr}}
                        {{post.body.slice(0,100)}}
                        </p>
                    </div>
                </router-link>
            </div>
            <el-pagination id="heihei"
                background
                layout="prev, pager, next"
                :total="total"
                :page-size="pageSize"
                :current-page="currentPage"
                @current-change="changePage"
             />
        </div>
       
    </div>
</template>
<style scoped>

.bt{
    margin-left: 1em;
}
p{
    margin-left: 1em;
}


.post-list{
    margin-top: 5%;
    float: left;
    width: 60%;
    margin-left: 15%;

}
.inpt{
  width: 50%;
  margin: auto;
  margin-top: 5em;
  margin-left: 18em;
}
.ser_result{
    margin: 0em;

    /* margin-top: 15%; */
    width: 100%;
    background-color:rgb(241, 246, 237);
    /* border: solid 0.1rem rgb(238, 36, 36); */
}
.pages{
    width: 50%;
    height: 2em;
    margin-left: 1em;
    margin-bottom: 0.2em;
    background-color: green;
}
#heihei{
    margin-left: 12%;
    /* margin-left: -25%; */
}
</style>