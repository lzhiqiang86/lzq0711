<script setup>
</script>
<template>
    <div class="keywords">
        <h1 class="gjc">关键词</h1>
        <p>天津</p>
        <p>轨道交通</p>
        <p>设计</p>
        <p>车辆</p>
        <p>智能</p>
        <p>研究院</p>
    </div>
</template>
<style scoped>
p{
    margin-left: 2rem;
}
.keywords{
    width: 20%;
    height: 30em;
    margin-top: 5em;
    margin-right: 4em;
    float: right;
    background-color: rgb(244, 240, 240);
    /* margin: 2em; */
}
.gjc{
    text-align: center;

}
</style>