<template>
<!-- <div class="wai" @click="dd">dddd</div> -->
<iframe class="wai" :src="toUrl" ></iframe>
</template>

<script setup>
import {useRoute} from "vue-router";
let tp = useRoute();
// console.log('here')
// console.log(tp.query.tp);
// console.log('here')
// const toUrl = "src/qg.pdf";
const toUrl = tp.query.tp;


</script>

<style scoped>
.wai{
  width: 100%;
  height: 100%;
  background-color: rgb(190, 39, 39);
}
</style>