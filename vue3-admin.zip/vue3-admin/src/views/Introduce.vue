

<script setup>
import PostList from '../components/PostList.vue'
import { ref } from 'vue';
import Keywords from '../components/Keywords.vue'

//传参数到postlist


</script>

<template>
  
<div>
  <PostList />
  <!-- <Keywords/> -->

</div>

</template>
<style scoped>

</style>