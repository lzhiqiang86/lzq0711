import {ref} from "vue";
import axios from "axios";
const getPosts = ()=>{
    const posts = ref([]);
    const load = async()=>{
    try {
    //   let data= await axios("http://localhost:3308/post")
      let {data} = await axios("http://localhost:3308/post")
  
      posts.value = data;
    //   postss = posts.value.data;
      console.log('hhhhhhhhhhhhh')
// post.value = data;
    } catch (error) {
      console.log(error)
    }
  }
  
  load();
  return { posts }
}
export default getPosts